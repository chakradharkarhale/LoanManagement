package com.example.Pegination;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeginationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeginationApplication.class, args);
	}

}
